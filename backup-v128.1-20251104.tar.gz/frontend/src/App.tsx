import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import { ThemeProvider } from './contexts/ThemeContext';
import ErrorBoundary from './components/ErrorBoundary';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import LeadsPage from './pages/LeadsPage';
import ChatPage from './pages/ChatPage';
import AgendaPage from './pages/AgendaPage';
import ProntuariosPage from './pages/ProntuariosPage';
import FinanceiroPage from './pages/FinanceiroPage';
import VendasPage from './pages/Vendas/VendasPage';
import PacientesPage from './pages/PacientesPage';
import PacienteFormPage from './pages/PacienteFormPage';
import PacienteFichaPage from './pages/PacienteFichaPage';
import EstoquePage from './pages/EstoquePage';
import ConfiguracoesPage from './pages/ConfiguracoesPage';
import IntegracoesPagamentosPage from './pages/IntegracoesPagamentosPage';
import BIDashboard from './pages/BI/BIDashboard';
import MarketingPage from './pages/MarketingPage';
import RedesSociaisPage from './pages/RedesSociaisPage';
import ProtectedRoute from './components/auth/ProtectedRoute';
import MainLayout from './components/layout/MainLayout';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <QueryClientProvider client={queryClient}>
          <BrowserRouter>
            <Routes>
          {/* Public routes */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />

          {/* Protected routes */}
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <Navigate to="/dashboard" replace />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <DashboardPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/leads"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <LeadsPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/chat"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <ChatPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/agenda"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <AgendaPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/prontuarios"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <ProntuariosPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/pacientes"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <PacientesPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/pacientes/novo"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <PacienteFormPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/pacientes/:id"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <PacienteFichaPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/pacientes/:id/editar"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <PacienteFormPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/financeiro"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <FinanceiroPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/financeiro/*"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <FinanceiroPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/vendas"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <VendasPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/vendas/*"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <VendasPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/estoque"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <EstoquePage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/estoque/*"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <EstoquePage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/automation"
            element={<Navigate to="/marketing" replace />}
          />
          <Route
            path="/bi"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <BIDashboard />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/bi/*"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <BIDashboard />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/colaboracao"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="text-center py-12">
                    <h2 className="text-2xl font-bold mb-4">Colaboração</h2>
                    <p className="text-gray-600">Em desenvolvimento...</p>
                  </div>
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/marketing"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <MarketingPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/marketing/*"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <MarketingPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/redes-sociais"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <RedesSociaisPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/configuracoes"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <ConfiguracoesPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/configuracoes/integracoes/pagamentos"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <IntegracoesPagamentosPage />
                </MainLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/settings"
            element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="text-center py-12">
                    <h2 className="text-2xl font-bold mb-4">Configurações</h2>
                    <p className="text-gray-600">Em desenvolvimento...</p>
                  </div>
                </MainLayout>
              </ProtectedRoute>
            }
          />
        </Routes>
      </BrowserRouter>
      <Toaster position="top-right" />
    </QueryClientProvider>
    </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
