# ⚠️ CONFIGURAÇÃO DNS NECESSÁRIA

## Problema Identificado

O domínio **nexusatemporal.com** não está resolvendo no DNS público.

### Diagnóstico Realizado

```bash
$ nslookup nexusatemporal.com 8.8.8.8
Server can't find nexusatemporal.com: NXDOMAIN
```

**Status**: O domínio não aponta para nenhum IP no momento.

---

## ✅ Solução: Configurar DNS

Você precisa configurar os registros DNS do domínio `nexusatemporal.com` no seu provedor de domínios (GoDaddy, Namecheap, Cloudflare, etc.).

### 1️⃣ Registros DNS Necessários

Adicione os seguintes registros **A** no painel de controle do seu domínio:

```
Tipo    Nome                          Valor         TTL
----    ----                          -----         ---
A       nexusatemporal.com            72.60.5.29    3600
A       www.nexusatemporal.com        72.60.5.29    3600
A       app.nexusatemporal.com        72.60.5.29    3600
A       api.nexusatemporal.com        72.60.5.29    3600
```

### 2️⃣ Como Configurar (Dependendo do Provedor)

#### Se estiver usando GoDaddy:
1. Acesse: https://dcc.godaddy.com/manage/dns
2. Selecione o domínio `nexusatemporal.com`
3. Clique em "Add" para adicionar novo registro
4. Tipo: A, Nome: @ (para raiz) ou www/app/api, Valor: 72.60.5.29
5. Repita para cada registro
6. Salve as alterações

#### Se estiver usando Cloudflare:
1. Acesse: https://dash.cloudflare.com
2. Selecione o domínio `nexusatemporal.com`
3. Vá em "DNS" → "Records"
4. Clique em "Add record"
5. Adicione cada registro A conforme a tabela acima
6. **IMPORTANTE**: Desative o proxy (ícone de nuvem cinza) para cada registro

#### Se estiver usando Namecheap:
1. Acesse: https://ap.www.namecheap.com
2. Clique em "Domain List" e selecione `nexusatemporal.com`
3. Vá em "Advanced DNS"
4. Adicione os registros A conforme a tabela
5. Salve

#### Outros Provedores:
- GoDaddy, Hostgator, UOL Host, etc. têm painel similar
- Procure por "DNS Management" ou "Gerenciar DNS"
- Adicione os registros A conforme a tabela

---

## ⏱️ Tempo de Propagação

Após adicionar os registros DNS:
- **Mínimo**: 15-30 minutos
- **Máximo**: 24-48 horas (raro)
- **Típico**: 1-4 horas

### Como Verificar se Propagou

```bash
# Teste 1: Via Google DNS
nslookup nexusatemporal.com 8.8.8.8

# Teste 2: Via Cloudflare DNS
nslookup nexusatemporal.com 1.1.1.1

# Teste 3: Online
# Acesse: https://dnschecker.org
# Digite: nexusatemporal.com
```

**Quando estiver OK**, você verá:
```
Server:		8.8.8.8
Address:	8.8.8.8#53

Name:	nexusatemporal.com
Address: 72.60.5.29
```

---

## 🔧 Configurações do Servidor (Já Feitas)

✅ **Website rodando**: nexus-website_website
✅ **Traefik configurado**: Roteamento e SSL prontos
✅ **Let's Encrypt**: Vai gerar certificado automaticamente após DNS propagar
✅ **Redirect WWW**: www → domínio principal

### Traefik está esperando o DNS para:
- Gerar certificado SSL automaticamente
- Rotear tráfego HTTPS para o website
- Ativar redirect de www para domínio principal

---

## 🧪 Teste Temporário (Enquanto DNS não Propaga)

Você pode testar o site **agora mesmo** usando o IP diretamente:

### Opção 1: Via curl com Host header
```bash
curl -k -H "Host: nexusatemporal.com" https://72.60.5.29
```

### Opção 2: Editar arquivo /etc/hosts (Linux/Mac)
```bash
# Adicione no arquivo /etc/hosts:
sudo nano /etc/hosts

# Adicione esta linha:
72.60.5.29    nexusatemporal.com www.nexusatemporal.com

# Salve e teste no navegador:
# https://nexusatemporal.com
```

### Opção 3: Editar arquivo hosts (Windows)
```
1. Abra o Bloco de Notas como Administrador
2. Abra: C:\Windows\System32\drivers\etc\hosts
3. Adicione: 72.60.5.29    nexusatemporal.com
4. Salve
5. Acesse: https://nexusatemporal.com
```

⚠️ **Atenção**: Esta é apenas uma solução temporária para testes locais!

---

## 📋 Checklist Pós-DNS

Após o DNS propagar, verifique:

- [ ] `nexusatemporal.com` resolve para 72.60.5.29
- [ ] `www.nexusatemporal.com` resolve para 72.60.5.29
- [ ] Site acessível via HTTPS (https://nexusatemporal.com)
- [ ] Certificado SSL válido (Let's Encrypt gerado automaticamente)
- [ ] Redirect de www funcionando (www → domínio principal)
- [ ] Site exibindo corretamente (landing page, planos, checkout)
- [ ] Dark/Light mode funcionando
- [ ] Todas as páginas acessíveis

---

## 🆘 Problemas Comuns

### "Este site não pode ser acessado"
❌ DNS ainda não propagou
✅ Aguarde mais tempo ou use teste temporário acima

### "Sua conexão não é particular" (SSL)
❌ Let's Encrypt ainda não gerou o certificado
✅ Aguarde alguns minutos após DNS propagar
✅ Verifique logs: `docker service logs traefik_traefik -f`

### "404 Page Not Found"
❌ Traefik não está roteando corretamente
✅ Verifique labels: `docker service inspect nexus-website_website`

### Site carrega mas não estilizado
❌ Build do Next.js pode ter falhado
✅ Verifique logs: `docker service logs nexus-website_website -f`

---

## 📞 Próximos Passos

1. **AGORA**: Configure DNS no seu provedor
2. **Após 1-4 horas**: Verifique se DNS propagou
3. **Teste o site**: https://nexustemporal.com.br
4. **Próxima fase**: Integração com backend para registro automático

---

## 🔍 Comandos de Monitoramento

```bash
# Ver status do serviço
docker service ps nexus-website_website

# Ver logs em tempo real
docker service logs nexus-website_website -f

# Ver logs do Traefik (para debug de SSL)
docker service logs traefik_traefik -f | grep nexusatemporal

# Testar acesso local
curl -k -I https://72.60.5.29 -H "Host: nexusatemporal.com"
```

---

**Status Atual do Deploy**: ✅ Website funcionando, aguardando apenas DNS
**IP do Servidor**: 72.60.5.29
**Data**: 2025-10-21
